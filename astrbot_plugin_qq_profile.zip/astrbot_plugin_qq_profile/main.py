"""修改机器人 QQ 昵称与头像的 AstrBot 插件。

适用于 aiocqhttp（OneBot v11）平台，协议端推荐 NapCat，
也兼容实现了 ``set_qq_profile`` / ``set_qq_avatar`` 的 Lagrange、LLOneBot 等。
"""

from __future__ import annotations

import re
import time
from typing import Any

import astrbot.api.message_components as Comp
from astrbot.api import AstrBotConfig, logger
from astrbot.api.event import AstrMessageEvent, filter
from astrbot.api.star import Context, Star

PLUGIN_NAME = "astrbot_plugin_qq_profile"
MAX_NICKNAME_LENGTH = 36
AVATAR_URL_PATTERN = re.compile(r"^https?://", re.IGNORECASE)
WAKE_PREFIXES = ("/", "／", "!", "！", "#", "＃")

HELP_TEXT = (
    "QQ 资料修改\n"
    "────────────\n"
    "改昵称：/改昵称 <新昵称>\n"
    "改头像：/改头像  （同一条消息附带图片，或引用一张图片）\n"
    "         /改头像 <图片链接>\n"
    "查资料：/我的资料\n"
    "看帮助：/改资料帮助\n"
    "────────────\n"
    "英文别名：/setnick、/setavatar、/myprofile、/qqprofilehelp"
)


class QQProfilePlugin(Star):
    """通过 OneBot v11 原生 API 修改机器人 QQ 资料。"""

    def __init__(self, context: Context, config: AstrBotConfig | None = None):
        super().__init__(context)
        self.config: Any = config if config is not None else {}
        # 全局冷却（所有使用者共享），避免频繁修改触发风控
        self._last_modify_at = 0.0

    # ------------------------------------------------------------------
    # 配置与权限
    # ------------------------------------------------------------------
    def _cfg(self, key: str, default: Any) -> Any:
        try:
            value = self.config.get(key, default)
        except Exception:
            return default
        return default if value is None else value

    def _is_allowed(self, event: AstrMessageEvent) -> bool:
        if not bool(self._cfg("admin_only", True)):
            return True

        try:
            if event.is_admin():
                return True
        except Exception:
            pass

        try:
            sender_id = str(event.get_sender_id())
        except Exception:
            return False

        extra_admins = self._cfg("extra_admins", []) or []
        return sender_id in {str(item).strip() for item in extra_admins}

    def _cooldown_left(self) -> int:
        try:
            seconds = int(self._cfg("cooldown_seconds", 30) or 0)
        except (TypeError, ValueError):
            seconds = 30
        if seconds <= 0:
            return 0
        return max(0, seconds - int(time.monotonic() - self._last_modify_at))

    # ------------------------------------------------------------------
    # 平台与 API 调用
    # ------------------------------------------------------------------
    @staticmethod
    def _get_client(event: AstrMessageEvent) -> Any | None:
        try:
            if event.get_platform_name() != "aiocqhttp":
                return None
        except Exception:
            return None
        client = getattr(event, "bot", None)
        return client if hasattr(client, "call_action") else None

    @staticmethod
    async def _call(client: Any, action: str, **params: Any) -> Any:
        ret = await client.call_action(action, **params)
        if isinstance(ret, dict):
            retcode = ret.get("retcode", 0)
            if ret.get("status") == "failed" or retcode not in (0, None):
                reason = (
                    ret.get("wording")
                    or ret.get("message")
                    or f"retcode={retcode}"
                )
                raise RuntimeError(str(reason))
            # 兼容返回完整响应体（而非仅 data）的协议端实现
            if "data" in ret and ("retcode" in ret or ret.get("status") == "ok"):
                return ret.get("data")
        return ret

    # ------------------------------------------------------------------
    # 消息解析
    # ------------------------------------------------------------------
    @staticmethod
    def _messages(event: AstrMessageEvent) -> list[Any]:
        try:
            return list(event.get_messages() or [])
        except Exception:
            pass
        chain = getattr(getattr(event, "message_obj", None), "message", None)
        return list(chain or [])

    @staticmethod
    def _argument(event: AstrMessageEvent, commands: tuple[str, ...]) -> str:
        """取命令后面的全部文本（保留空格），命令名来自装饰器。"""
        text = (event.get_message_str() or "").strip()
        for prefix in WAKE_PREFIXES:
            if text.startswith(prefix):
                text = text[len(prefix) :].lstrip()
                break
        for command in sorted(commands, key=len, reverse=True):
            if text == command:
                return ""
            if text.startswith(command):
                rest = text[len(command) :]
                if not rest or rest[0].isspace():
                    return rest.strip()
        parts = text.split(maxsplit=1)
        return parts[1].strip() if len(parts) > 1 else ""

    async def _find_image(
        self, event: AstrMessageEvent, client: Any
    ) -> tuple[str | None, Any | None]:
        """返回（图片 URL, 图片组件）。图片可来自当前消息、引用消息或 get_msg。"""
        messages = self._messages(event)

        for comp in messages:
            if isinstance(comp, Comp.Image):
                url = self._image_url(comp)
                return url, comp

        reply = next((c for c in messages if isinstance(c, Comp.Reply)), None)
        if reply is None:
            return None, None

        for comp in getattr(reply, "chain", None) or []:
            if isinstance(comp, Comp.Image):
                return self._image_url(comp), comp

        message_id = getattr(reply, "id", None)
        if not message_id:
            return None, None
        try:
            ret = await self._call(client, "get_msg", message_id=message_id)
        except Exception as exc:
            logger.warning(f"[qq_profile] 获取引用消息失败：{exc}")
            return None, None

        for segment in (ret or {}).get("message", []) or []:
            if segment.get("type") != "image":
                continue
            data = segment.get("data") or {}
            source = (data.get("url") or data.get("file") or "").strip()
            if not source:
                continue
            url = source if AVATAR_URL_PATTERN.match(source) else None
            return url, Comp.Image(file=source, url=url or "")
        return None, None

    @staticmethod
    def _image_url(image: Any) -> str | None:
        for attr in ("url", "file"):
            value = getattr(image, attr, "") or ""
            value = value.strip()
            if AVATAR_URL_PATTERN.match(value):
                return value
        return None

    @staticmethod
    async def _image_base64(image: Any) -> str | None:
        convert = getattr(image, "convert_to_base64", None)
        if convert is None:
            return None
        try:
            data = await convert()
            return data or None
        except Exception as exc:
            logger.warning(f"[qq_profile] 图片转 base64 失败：{exc}")
            return None

    # ------------------------------------------------------------------
    # 业务实现
    # ------------------------------------------------------------------
    async def _do_set_nickname(
        self, event: AstrMessageEvent, commands: tuple[str, ...]
    ):
        if not self._is_allowed(event):
            yield event.plain_result("你没有权限修改机器人资料。")
            return

        client = self._get_client(event)
        if client is None:
            yield event.plain_result(
                "该指令仅支持 OneBot v11 协议端（如 NapCat、Lagrange），"
                "QQ 官方机器人平台无法修改资料。"
            )
            return

        raw_name = self._argument(event, commands)
        if not raw_name:
            yield event.plain_result("用法：/改昵称 <新昵称>")
            return

        name = re.sub(r"\s+", " ", raw_name).strip()
        if not name:
            yield event.plain_result("昵称不能为空。")
            return
        if len(name) > MAX_NICKNAME_LENGTH:
            yield event.plain_result(
                f"昵称太长了，最多 {MAX_NICKNAME_LENGTH} 个字符。"
            )
            return

        left = self._cooldown_left()
        if left > 0:
            yield event.plain_result(f"操作太频繁，请 {left} 秒后再试。")
            return
        self._last_modify_at = time.monotonic()

        try:
            await self._call(client, "set_qq_profile", nickname=name)
        except Exception as exc:
            logger.error(f"[qq_profile] 修改昵称失败：{exc}")
            yield event.plain_result(
                f"修改昵称失败：{self._short(exc)}\n"
                "请确认协议端支持 set_qq_profile，且机器人账号状态正常。"
            )
            return

        yield event.plain_result(
            f"已把机器人昵称改为「{name}」。\nQQ 资料可能有几秒延迟，稍后刷新即可看到。"
        )

    async def _do_set_avatar(
        self, event: AstrMessageEvent, commands: tuple[str, ...]
    ):
        if not self._is_allowed(event):
            yield event.plain_result("你没有权限修改机器人资料。")
            return

        client = self._get_client(event)
        if client is None:
            yield event.plain_result(
                "该指令仅支持 OneBot v11 协议端（如 NapCat、Lagrange），"
                "QQ 官方机器人平台无法修改资料。"
            )
            return

        argument = self._argument(event, commands)
        url: str | None = None
        image: Any | None = None

        if argument:
            if not AVATAR_URL_PATTERN.match(argument):
                yield event.plain_result(
                    "用法：/改头像 <图片链接>\n"
                    "或直接发送 /改头像 并在同一条消息里附带图片。"
                )
                return
            url = argument
        else:
            url, image = await self._find_image(event, client)
            if not url and image is None:
                yield event.plain_result(
                    "没有找到图片。请把图片和 /改头像 一起发送，"
                    "或引用一张图片后再发送 /改头像。"
                )
                return

        left = self._cooldown_left()
        if left > 0:
            yield event.plain_result(f"操作太频繁，请 {left} 秒后再试。")
            return
        self._last_modify_at = time.monotonic()

        try:
            await self._apply_avatar(client, url, image)
        except Exception as exc:
            logger.error(f"[qq_profile] 修改头像失败：{exc}")
            yield event.plain_result(
                f"修改头像失败：{self._short(exc)}\n"
                "请确认图片可访问、格式为常见图片（jpg/png/gif），且协议端支持 set_qq_avatar。"
            )
            return

        yield event.plain_result("头像已更新。QQ 资料可能有几秒延迟，稍后刷新即可看到。")

    async def _apply_avatar(
        self, client: Any, url: str | None, image: Any | None
    ) -> None:
        prefer_url = bool(self._cfg("avatar_prefer_url", True))
        errors: list[str] = []

        if prefer_url and url:
            try:
                await self._call(client, "set_qq_avatar", file=url)
                return
            except Exception as exc:
                errors.append(f"URL：{exc}")
                logger.warning(f"[qq_profile] set_qq_avatar(url) 失败：{exc}")

        if image is not None:
            encoded = await self._image_base64(image)
            if encoded:
                try:
                    await self._call(
                        client, "set_qq_avatar", file=f"base64://{encoded}"
                    )
                    return
                except Exception as exc:
                    errors.append(f"base64：{exc}")
                    logger.warning(
                        f"[qq_profile] set_qq_avatar(base64) 失败：{exc}"
                    )

        if not prefer_url and url:
            try:
                await self._call(client, "set_qq_avatar", file=url)
                return
            except Exception as exc:
                errors.append(f"URL：{exc}")
                logger.warning(f"[qq_profile] set_qq_avatar(url) 失败：{exc}")

        if not errors:
            raise RuntimeError("没有可用于设置头像的图片")
        raise RuntimeError("；".join(errors[-2:]))

    async def _do_profile(self, event: AstrMessageEvent):
        if not self._is_allowed(event):
            yield event.plain_result("你没有权限查看机器人资料。")
            return

        client = self._get_client(event)
        if client is None:
            yield event.plain_result("该指令仅支持 OneBot v11 协议端。")
            return

        try:
            info = await self._call(client, "get_login_info")
        except Exception as exc:
            logger.error(f"[qq_profile] 查询资料失败：{exc}")
            yield event.plain_result(f"查询资料失败：{self._short(exc)}")
            return

        info = info if isinstance(info, dict) else {}
        uin = info.get("user_id")
        nickname = info.get("nickname") or "未知"
        if not uin:
            yield event.plain_result("查询失败：协议端没有返回 QQ 号。")
            return

        yield event.plain_result(
            "机器人当前资料\n"
            "────────────\n"
            f"QQ 号：{uin}\n"
            f"昵称：{nickname}\n"
            f"头像：https://q1.qlogo.cn/g?b=qq&nk={uin}&s=640"
        )

    @staticmethod
    def _short(value: Any, limit: int = 160) -> str:
        text = str(value).strip() or "未知错误"
        return text if len(text) <= limit else text[:limit] + "…"

    # ------------------------------------------------------------------
    # 指令
    # ------------------------------------------------------------------
    @filter.command("改昵称")
    async def cmd_set_nickname(self, event: AstrMessageEvent):
        async for result in self._do_set_nickname(event, ("改昵称",)):
            yield result

    @filter.command("setnick")
    async def cmd_set_nickname_en(self, event: AstrMessageEvent):
        async for result in self._do_set_nickname(event, ("setnick",)):
            yield result

    @filter.command("改qq昵称")
    async def cmd_set_nickname_alias(self, event: AstrMessageEvent):
        async for result in self._do_set_nickname(event, ("改qq昵称",)):
            yield result

    @filter.command("改头像")
    async def cmd_set_avatar(self, event: AstrMessageEvent):
        async for result in self._do_set_avatar(event, ("改头像",)):
            yield result

    @filter.command("setavatar")
    async def cmd_set_avatar_en(self, event: AstrMessageEvent):
        async for result in self._do_set_avatar(event, ("setavatar",)):
            yield result

    @filter.command("改qq头像")
    async def cmd_set_avatar_alias(self, event: AstrMessageEvent):
        async for result in self._do_set_avatar(event, ("改qq头像",)):
            yield result

    @filter.command("我的资料")
    async def cmd_profile(self, event: AstrMessageEvent):
        async for result in self._do_profile(event):
            yield result

    @filter.command("myprofile")
    async def cmd_profile_en(self, event: AstrMessageEvent):
        async for result in self._do_profile(event):
            yield result

    @filter.command("改资料帮助")
    async def cmd_help(self, event: AstrMessageEvent):
        yield event.plain_result(HELP_TEXT)

    @filter.command("qqprofilehelp")
    async def cmd_help_en(self, event: AstrMessageEvent):
        yield event.plain_result(HELP_TEXT)
